#include "mbed.h"
#include "AD9117.h"
 
Serial pc(SERIAL_TX, SERIAL_RX);
AD9117 outputDAC;

int main() {
    
    while(1) {
        
        for (int i=0;i<0x15;i++){
            if(i%3==0) {pc.printf("\n");}
            uint8_t registerValue = outputDAC.readRegister(i);
            pc.printf("[0x%x]=0x%x\t",i,registerValue);
            wait_ms(200);
        }
        pc.printf("\n\n");
        
    }
}
 
 
 /*for (int i=0;i<0x15;i++){
            if(i%3==0) {pc.printf("\n");}
            cs = 0;
                wait_ms(1);
                sendByte(0x80+i);  uint8_t value = readBytes();  
                pc.printf("[0x%x]=0x%x\t",i,value);
                wait_ms(1);
            cs = 1;  
            
            mySDIO.output(); mySDIO=0;
            wait_ms(100);
            cs=0; wait_ms(1); sendByte(0x01);  sendByte(0x48);  wait_ms(1);   cs=1;
            wait_ms(100);
        }
        pc.printf("\n\n");*/
#include "AD9245.h"

void AD9245::init(void){
}

int AD9245::read(void){
    for (int i = 0; i < 3; i++)
            asm("nop");
    return 0;
}
#ifndef __AD9245_H
#define __AD9245_H


#include "mbed.h"


class AD9245{
    private:
    public:
        void init();
        int read();
};



#endif /* __AD9245_H */
#include "mbed.h"

//------------------------------------
// Hyperterminal configuration
// 9600 bauds, 8-bit data, no parity
//------------------------------------

Serial pc(SERIAL_TX, SERIAL_RX);
 
DigitalOut myled(LED1);

DigitalOut LE(PB_8); 
DigitalOut mySCLK(PB_2);
DigitalOut mySDIO(PB_1);
DigitalIn myLOCK(PB_15);

uint32_t pow2(int val);

void sendToADF4351(uint32_t val){
    for (int i=0;i<32;i++){
            mySCLK = 0;  //CLK low
        wait_ms(1);
            if(val & pow2(31-i)){
                mySDIO = 1;
            }
            else
                mySDIO = 0;
        wait_ms(1);
            mySCLK = 1;   //CLK high sends data
        wait_ms(1);
    }
    wait_ms(1);
        LE = 1;
    wait_ms(1);
        mySCLK = 0; 
        LE=0;
        mySDIO=0;
    wait_ms(1);
}

int INT = 320;      //set the Vco freq at 2.5GHz
int FRAC = 0;

#define PHASE_ADJ   0   // OFF
#define PRESCALER   0   // 1-8/9        0-4/5
#define PHASE       1
#define MOD         1000

#define LOW_NOISE_LOW_SPUR  0   //0 Low noise mode      (3 -> low spur mode)
#define MUXOUT              0
#define REF_DOUBLER         0       //0 disabled        1 enabled       setting the F_pfd to 100kHz
#define REF_DIVIDER         0       //0 disabled        1 enabled       -------------//------------
#define R_COUNTER           1000    //                                  -------------//------------
#define DOUBLED_BUFFER      0       //0 disabled        1 enabled
#define CHARGE_PUMP         10       //Icp = 2.5mA
#define LDF                 0       //1-INT-N       0-FRAC-N
#define LDP                 0       //1-6ns (INT-N) 0-10ns (FRAC-N)
#define PD_POLARITY         1       //1-positive    0-negative
#define POWER_DOWN          0       //0-disabled    1-enabled
#define CP_THREE_STATE      0       //0-disabled (normal operation)     1-enabled
#define COUNTER_RST         0       //0-disabled    1-enabled (if set to 1 N counter and R counter are held in reset)

#define BAND_SELECT         0       // 0 -(if PFD <125kHz) if set to 1 clock divider must be less than 255.
#define ABP                 0       //1-3ns(INT-N)   0-6ns(FRAC-N)
#define CHARGE_CANCEL       0       //0 (Frac-N ) 1 (Int-N)
#define CSR                 0       //0 disabled    1 enabled
#define CLOCK_DIV_MODE      0       //0 clock divider off
#define CLOCK_DIV_VAL       150     //0-4095

#define FEDBACK_SEL         1       //0-divided     1-fundamental
int RF_DIV_SEL = 3;     //          divider = 2^value
#define BAND_SEL_CLK_DIV    200
#define VCO_POWER_DOWN      0       //0->VCO powered up     1->vco powered down
#define MTLD                0       //0->mute disabled      1->mute enabled
#define AUX_OUT_SEL         0       //0->divided output 1->fundamental
#define AUX_OUT_ENABLED     0       //0-AUX disabled        1-AUX enabled
#define AUX_OUT_POWER       0       //-4dBm
#define RF_OUT_ENABLED      1       //0->disabled           1->enabled
#define OUT_POWER           3       //+5dBm

#define LD_PIN_MODE         1       //0-low 1-digital lock detect 2-low 3-high

int64_t Adf4351_SetFrequency( int64_t freqHz )
{
    double Fin;
    double Fpsd;
    double frac;
    double Fvco;
    int    mul,divCode;
    unsigned int prevR4;


    if( freqHz/1e6 < 34 ){
        //fprintf(stdout,"f=%f too low\n",(double)freqHz);
        return(1);
    }
    if( freqHz/1e6 > 4500 ){
        //fprintf(stdout,"f=%f too high\n",(double)freqHz);
        return(1);
    }

    // Reference frequency specified by oscillator on board
    Fin  = 100000000;
    Fpsd = Fin/1000;

    // Fvco must be within 2300Mhz - 4500Mhz
    Fvco = freqHz;
    mul  = 1;
    while( Fvco < 2300e6 ){
       mul  = mul  * 2;
       Fvco = Fvco * 2;
    }

    uint16_t mInt = Fvco / Fpsd;
    frac = ( Fvco - (mInt*Fpsd) )/Fpsd;
    uint16_t mMod = 1000;
    uint16_t mFrac= frac * mMod;

    freqHz = (mInt*Fpsd + Fpsd*mFrac/mMod )/mul;

    switch( mul ){
        case  1: divCode = 0;break;
        case  2: divCode = 1;break;
        case  4: divCode = 2;break;
        case  8: divCode = 3;break;
        case 16: divCode = 4;break;
        case 32: divCode = 5;break;
        case 64: divCode = 6;break;
        default: divCode = 6;break;
    }

    INT=mInt;
    FRAC=mFrac;
    RF_DIV_SEL=divCode;

    return( freqHz );
}

volatile int64_t setFrequency=35e6;

volatile char rx_buffer[10];
volatile int i_rx_buffer=0;

volatile int freqChanged=0;

void rx_int() {
    char c = pc.getc();
    
    rx_buffer[i_rx_buffer]=c;
    i_rx_buffer++;
    if(i_rx_buffer==10) i_rx_buffer=9;
    
    if(c=='\n'){
        int rxFreq = atoi((const char*)rx_buffer);
        
        setFrequency=(int64_t)rxFreq*1e6;
    
        for (int i=0;i<10;i++) rx_buffer[i]=0;
        i_rx_buffer=0;
        
        pc.printf("Freq: %dMHz\n",(int)(setFrequency/1e6));
        freqChanged=0;
    }
}
 
int main() {
  int i=0;
  i_rx_buffer=0;
  
  pc.printf("Hello World !\n");
  
  setFrequency=45e6;
  
  Adf4351_SetFrequency(setFrequency);
  pc.printf("I: %d, N: %d, DIV: %d\n", INT, FRAC, RF_DIV_SEL);
  
  pc.printf("Freq: %dMHz\n",(int)(setFrequency/1e6));
  
  pc.attach(&rx_int);
  
  while(1) { 
      
      Adf4351_SetFrequency(setFrequency);
        

        uint32_t reg0 = INT*32768 + FRAC*8;
        uint32_t reg1 = PHASE_ADJ*pow2(28) + PRESCALER*pow2(27) + PHASE*pow2(15) + MOD*pow2(3) + 1;
        uint32_t reg2 = LOW_NOISE_LOW_SPUR*pow2(29)+MUXOUT*pow2(26)+REF_DOUBLER*pow2(25)+
                        REF_DIVIDER*pow2(24)+R_COUNTER*pow2(14)+DOUBLED_BUFFER*pow2(13)+
                        CHARGE_PUMP*pow2(9)+LDF*pow2(8)+LDP*pow2(7)+PD_POLARITY*pow2(6)+
                        POWER_DOWN*pow2(5)+CP_THREE_STATE*pow2(4)+COUNTER_RST*pow2(3)+2;
        uint32_t reg3 = BAND_SELECT*pow2(23)+ABP*pow2(22)+CHARGE_CANCEL*pow2(21)+
                        CSR*pow2(18)+CLOCK_DIV_MODE*pow2(15)+CLOCK_DIV_VAL*pow2(3)+3;
        uint32_t reg4 = FEDBACK_SEL*pow2(23)+RF_DIV_SEL*pow2(20)+BAND_SEL_CLK_DIV*pow2(12)+
                        VCO_POWER_DOWN*pow2(11)+MTLD*pow2(10)+AUX_OUT_SEL*pow2(9)+AUX_OUT_ENABLED*pow2(8)+
                        AUX_OUT_POWER*pow2(6)+RF_OUT_ENABLED*pow2(5)+OUT_POWER*pow2(3)+4;
        uint32_t reg5 = LD_PIN_MODE*pow2(22)+5;

        sendToADF4351(reg5);
        sendToADF4351(reg4);
        sendToADF4351(reg3);
        sendToADF4351(reg2);
        sendToADF4351(reg1);
        sendToADF4351(reg0);
        wait_ms(50);
        
        pc.printf("s");
        
        while(myLOCK && freqChanged==1) {
        }
        freqChanged=1;
  }
}

uint32_t pow2(int val){
    switch (val){
    case 0:
        return 1;
    case 1:
        return 2;
    case 2:
        return 4;
    case 3:
        return 8;
    case 4:
        return 16;
    case 5:
        return 32;
    case 6:
        return 64;
    case 7:
        return 128;
    case 8:
        return 256;
    case 9:
        return 512;
    case 10:
        return 1024UL;
    case 11:
        return 2048UL;
    case 12:
        return 4096UL;
    case 13:
        return 8192UL;
    case 14:
        return 16384UL;
    case 15:
        return 32768UL;
    case 16:
        return 65536UL;
    case 17:
        return 131072UL;
    case 18:
        return 262144UL;
    case 19:
        return 524288UL;
    case 20:
        return 1048576UL;
    case 21:
        return 2097152UL;
    case 22:
        return 4194304UL;
    case 23:
        return 8388608UL;
    case 24:
        return 16777216UL;
    case 25:
        return 33554432UL;
    case 26:
        return 67108864UL;
    case 27:
        return 134217728UL;
    case 28:
        return 268435456UL;
    case 29:
        return 536870912UL;
    case 30:
        return 1073741824UL;
    case 31:
        return 2147483648UL;
    }
    return 0;
}
 
 /*
 void sendByte( uint8_t data){
    mySDIO.output();
    
    if((data & (1<<8))>0){
        mySDIO = 1;
    }
    else {
        mySDIO=0;
    }
    wait_ms(1);
    for (int i=7;i>-1;i--){
        mySCLK=1;
        wait_ms(1);
        if((data & (1<<i))>0){
            mySDIO = 1;
        }
        else {
            mySDIO=0;
        }
        mySCLK = 0;
        wait_ms(1);
    }
    mySCLK=1;
    wait_ms(1);
}

uint8_t readByte(){
    uint8_t value=0;
    mySDIO.input();
    for (int i=7;i>-1;i--){
        mySCLK=0;
        wait_ms(1);
    
        if (mySDIO.read() > 0){
            value += (1<<i);
        }

        mySCLK = 1;
        wait_ms(1);
    }
    mySCLK=1;
    wait_ms(1);
    
    return value;
}*/